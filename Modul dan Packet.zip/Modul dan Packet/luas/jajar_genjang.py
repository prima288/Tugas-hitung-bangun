import math

def jajar_genjang(a,t):
    return a*t
