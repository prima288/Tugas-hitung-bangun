import math
phi = 22/7

def lingkaran(r):
    return phi*r*r