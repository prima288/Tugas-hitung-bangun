import math

def persegi(s):
    return s*s