import math

def persegi_panjang(p,l):
    return p*l