import math

def segitiga(a,t):
    return 1/2*a*t