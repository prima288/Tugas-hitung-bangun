import math

def trapesium(a,b,t):
    return (a+b)/2*t