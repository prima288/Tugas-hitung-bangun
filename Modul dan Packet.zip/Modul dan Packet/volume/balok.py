import math

def balok(p,l,t):
    return p*l*t
