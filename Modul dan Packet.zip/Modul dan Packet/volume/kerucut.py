import math

phi = 22/7
def kerucut(r,t):
    return 1/3*phi*r*r*t
