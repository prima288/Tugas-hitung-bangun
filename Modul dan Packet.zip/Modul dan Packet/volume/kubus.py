import math

def kubus(s):
    return s*s*s