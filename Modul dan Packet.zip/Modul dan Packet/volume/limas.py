import math

def limas(luas_alas,t):
    return 1/3*luas_alas*t