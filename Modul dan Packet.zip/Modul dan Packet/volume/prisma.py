import math

def prisma(luas_alas,t):
    return luas_alas*t