import math

phi = 22/7
def tabung(r,t):
    return phi*r*r*t